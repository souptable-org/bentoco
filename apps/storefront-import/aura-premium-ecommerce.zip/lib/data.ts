import { Product } from './types';

export const mockProducts: Product[] = [
  {
    id: 'p1',
    name: 'Handwoven Chanderi Silk Saree',
    slug: 'handwoven-chanderi-silk-saree',
    description: 'Experience the epitome of elegance with our handwoven Chanderi silk saree. Featuring delicate zari motifs and a weightless drape, perfect for festive occasions and weddings.',
    price: 12999,
    originalPrice: 15999,
    images: [
      'https://picsum.photos/seed/saree1/800/1000',
      'https://picsum.photos/seed/saree2/800/1000',
      'https://picsum.photos/seed/saree3/800/1000',
    ],
    category: 'Sarees',
    tags: ['Festive', 'Silk', 'Handloom'],
    isNew: true,
    rating: 4.8,
    reviews: 124,
    features: [
      'Authentic Chanderi Silk',
      'Intricate Zari Work',
      'Includes Unstitched Blouse Piece',
      'Dry Clean Only'
    ],
    details: {
      'Fabric': 'Chanderi Silk',
      'Pattern': 'Woven Design',
      'Length': '5.5 Metres',
      'Blouse': '0.8 Metres'
    }
  },
  {
    id: 'p2',
    name: 'Men\'s Linen Blend Kurta Set',
    slug: 'mens-linen-blend-kurta-set',
    description: 'A contemporary take on traditional wear. This premium linen blend kurta set offers breathable comfort with a sharp, tailored fit suitable for day events and pujas.',
    price: 4599,
    originalPrice: 5999,
    images: [
      'https://picsum.photos/seed/kurta1/800/1000',
      'https://picsum.photos/seed/kurta2/800/1000',
    ],
    category: 'Men',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'Ivory', value: '#FFFFF0' },
      { name: 'Sage Green', value: '#9DC183' }
    ],
    tags: ['Kurta', 'Festive', 'Linen'],
    rating: 4.5,
    reviews: 89,
    features: [
      'Premium Linen-Cotton Blend',
      'Mandarin Collar',
      'Includes Churidar Pajama',
      'Machine Washable'
    ],
    details: {
      'Fabric': 'Linen Blend',
      'Fit': 'Regular Fit',
      'Wash Care': 'Gentle Machine Wash'
    }
  },
  {
    id: 'p3',
    name: 'Kundan Polki Choker Set',
    slug: 'kundan-polki-choker-set',
    description: 'Adorn yourself in royal heritage. This handcrafted Kundan Polki choker set features uncut diamonds set in 22k gold plating, complete with matching jhumkas.',
    price: 24500,
    images: [
      'https://picsum.photos/seed/jewelry1/800/1000',
      'https://picsum.photos/seed/jewelry2/800/1000',
    ],
    category: 'Jewelry',
    tags: ['Bridal', 'Kundan', 'Choker'],
    rating: 4.9,
    reviews: 42,
    features: [
      '22k Gold Plated',
      'Handcrafted Kundan Work',
      'Hypoallergenic',
      'Secure Drawstring Closure'
    ],
    details: {
      'Material': 'Brass Alloy',
      'Plating': '22k Gold',
      'Stone Type': 'Kundan & Faux Pearls'
    }
  },
  {
    id: 'p4',
    name: 'Contemporary Block Print Midi',
    slug: 'contemporary-block-print-midi',
    description: 'Breezy and beautiful. Hand-block printed by artisans in Jaipur, this cotton midi dress is your perfect companion for summer brunches and casual outings.',
    price: 2899,
    originalPrice: 3499,
    images: [
      'https://picsum.photos/seed/dress1/800/1000',
      'https://picsum.photos/seed/dress2/800/1000',
    ],
    category: 'Dresses',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    tags: ['Cotton', 'Block Print', 'Casual'],
    isNew: true,
    rating: 4.6,
    reviews: 215,
    features: [
      '100% Pure Cotton',
      'Authentic Bagru Block Print',
      'Side Pockets',
      'Hand Wash Separately'
    ],
    details: {
      'Fabric': 'Cotton',
      'Length': 'Midi (45 inches)',
      'Pattern': 'Floral Block Print'
    }
  },
  {
    id: 'p5',
    name: 'Handcrafted Mojari Footwear',
    slug: 'handcrafted-mojari-footwear',
    description: 'Step into tradition with these pure leather mojaris, featuring intricate zari embroidery. Designed for comfort and undeniable style.',
    price: 1899,
    images: [
      'https://picsum.photos/seed/shoes1/800/1000',
      'https://picsum.photos/seed/shoes2/800/1000',
    ],
    category: 'Footwear',
    sizes: ['UK 6', 'UK 7', 'UK 8', 'UK 9', 'UK 10'],
    tags: ['Leather', 'Embroidered', 'Ethnic'],
    rating: 4.4,
    reviews: 76,
    features: [
      'Genuine Leather Sole',
      'Cushioned Insole',
      'Hand-embroidered Zari',
      'Slip-on Style'
    ],
    details: {
      'Material': 'Leather & Velvet',
      'Toe Type': 'Pointed',
      'Care': 'Wipe with clean dry cloth'
    }
  },
  {
    id: 'p6',
    name: 'Banarasi Silk Dupatta',
    slug: 'banarasi-silk-dupatta',
    description: 'Elevate any simple outfit with this opulent Banarasi silk dupatta, woven with rich gold motifs across vibrant jewel tones.',
    price: 3499,
    originalPrice: 4299,
    images: [
      'https://picsum.photos/seed/dupatta1/800/1000',
      'https://picsum.photos/seed/dupatta2/800/1000',
    ],
    category: 'Accessories',
    colors: [
      { name: 'Emerald Green', value: '#50C878' },
      { name: 'Ruby Red', value: '#E0115F' },
      { name: 'Royal Blue', value: '#4169E1' }
    ],
    tags: ['Banarasi', 'Silk', 'Festive'],
    rating: 4.7,
    reviews: 156,
    features: [
      'Pure Banarasi Silk',
      'Woven Zari Borders',
      'Tasselled Edges',
      'Dry Clean Only'
    ],
    details: {
      'Fabric': 'Silk Blend',
      'Length': '2.25 Metres',
      'Width': '36 Inches'
    }
  }
];

export const getProductBySlug = (slug: string) => {
  return mockProducts.find(p => p.slug === slug);
};

export const getRelatedProducts = (currentId: string, limit = 4) => {
  return mockProducts.filter(p => p.id !== currentId).slice(0, limit);
};
