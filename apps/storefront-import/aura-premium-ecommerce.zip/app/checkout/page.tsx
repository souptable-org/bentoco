'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useApp } from '@/lib/store';
import { ShieldCheck, ChevronLeft, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function CheckoutPage() {
  const { cart, cartTotal } = useApp();
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState('upi');
  const [orderId, setOrderId] = useState('');

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(price);
  };

  const total = cartTotal + (cartTotal * 0.18);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) setStep(2);
    else if (step === 2) {
      setOrderId(`AUR-${Math.floor(10000 + Math.random() * 90000)}`);
      setStep(3);
    }
  };

  if (cart.length === 0 && step !== 3) {
    return (
      <div className="min-h-[50vh] flex flex-col items-center justify-center text-center">
        <h1 className="font-serif text-2xl font-semibold mb-4">No items to checkout</h1>
        <Link href="/shop" className="text-accent underline underline-offset-4">Return to shop</Link>
      </div>
    );
  }

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col lg:flex-row gap-12 lg:gap-24">
        
        {/* Left Column: Form */}
        <div className="w-full lg:w-3/5">
          {step < 3 && (
            <Link href={step === 1 ? "/cart" : "#"} onClick={(e) => { if (step === 2) { e.preventDefault(); setStep(1); } }} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors">
              <ChevronLeft className="w-4 h-4" /> {step === 1 ? 'Back to Cart' : 'Back to Shipping'}
            </Link>
          )}

          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div key="step1" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}>
                <h1 className="font-serif text-3xl font-semibold mb-8">Shipping Information</h1>
                <form id="checkout-form" onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">First Name</label>
                      <input required type="text" className="w-full border border-border bg-background px-4 py-3 text-sm focus:outline-none focus:border-accent transition-colors" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Last Name</label>
                      <input required type="text" className="w-full border border-border bg-background px-4 py-3 text-sm focus:outline-none focus:border-accent transition-colors" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Email Address (for order updates)</label>
                    <input required type="email" className="w-full border border-border bg-background px-4 py-3 text-sm focus:outline-none focus:border-accent transition-colors" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Phone Number</label>
                    <div className="flex">
                      <span className="inline-flex items-center px-4 border border-r-0 border-border bg-muted text-sm text-muted-foreground">+91</span>
                      <input required type="tel" pattern="[0-9]{10}" placeholder="10-digit mobile number" className="w-full border border-border bg-background px-4 py-3 text-sm focus:outline-none focus:border-accent transition-colors" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Address</label>
                    <input required type="text" placeholder="House/Flat No., Building Name, Street" className="w-full border border-border bg-background px-4 py-3 text-sm focus:outline-none focus:border-accent transition-colors mb-2" />
                    <input type="text" placeholder="Locality / Landmark (Optional)" className="w-full border border-border bg-background px-4 py-3 text-sm focus:outline-none focus:border-accent transition-colors" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Pincode</label>
                      <input required type="text" maxLength={6} pattern="[0-9]{6}" className="w-full border border-border bg-background px-4 py-3 text-sm focus:outline-none focus:border-accent transition-colors" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">City</label>
                      <input required type="text" className="w-full border border-border bg-background px-4 py-3 text-sm focus:outline-none focus:border-accent transition-colors" />
                    </div>
                  </div>
                  <button type="submit" className="w-full bg-primary text-primary-foreground py-4 mt-8 font-medium uppercase tracking-widest text-sm hover:bg-primary/90 transition-colors">
                    Continue to Payment
                  </button>
                </form>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div key="step2" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}>
                <h1 className="font-serif text-3xl font-semibold mb-8">Payment Method</h1>
                <form id="payment-form" onSubmit={handleSubmit} className="space-y-6">
                  
                  <div className="border border-border divide-y divide-border rounded-sm overflow-hidden">
                    
                    {/* UPI */}
                    <label className={`flex items-center gap-4 p-4 cursor-pointer transition-colors ${paymentMethod === 'upi' ? 'bg-secondary/30' : 'hover:bg-muted/50'}`}>
                      <input type="radio" name="payment" value="upi" checked={paymentMethod === 'upi'} onChange={(e) => setPaymentMethod(e.target.value)} className="w-4 h-4 text-accent accent-accent" />
                      <div className="flex-1">
                        <span className="font-medium block">UPI (GPay, PhonePe, Paytm)</span>
                        <span className="text-xs text-muted-foreground">Instant, zero-fee payment</span>
                      </div>
                      <div className="flex gap-2 opacity-50 grayscale">
                        <div className="w-8 h-5 bg-background border border-border rounded flex items-center justify-center text-[8px] font-bold">UPI</div>
                      </div>
                    </label>

                    {/* Credit Card */}
                    <label className={`flex items-center gap-4 p-4 cursor-pointer transition-colors ${paymentMethod === 'card' ? 'bg-secondary/30' : 'hover:bg-muted/50'}`}>
                      <input type="radio" name="payment" value="card" checked={paymentMethod === 'card'} onChange={(e) => setPaymentMethod(e.target.value)} className="w-4 h-4 text-accent accent-accent" />
                      <div className="flex-1">
                        <span className="font-medium block">Credit / Debit Card</span>
                        <span className="text-xs text-muted-foreground">Visa, Mastercard, RuPay, Amex</span>
                      </div>
                    </label>
                    {paymentMethod === 'card' && (
                      <div className="p-4 bg-background border-t border-border space-y-4">
                        <input type="text" placeholder="Card Number" className="w-full border border-border bg-background px-4 py-3 text-sm focus:outline-none focus:border-accent" />
                        <div className="grid grid-cols-2 gap-4">
                          <input type="text" placeholder="MM/YY" className="w-full border border-border bg-background px-4 py-3 text-sm focus:outline-none focus:border-accent" />
                          <input type="text" placeholder="CVV" className="w-full border border-border bg-background px-4 py-3 text-sm focus:outline-none focus:border-accent" />
                        </div>
                      </div>
                    )}

                    {/* COD */}
                    <label className={`flex items-center gap-4 p-4 cursor-pointer transition-colors ${paymentMethod === 'cod' ? 'bg-secondary/30' : 'hover:bg-muted/50'}`}>
                      <input type="radio" name="payment" value="cod" checked={paymentMethod === 'cod'} onChange={(e) => setPaymentMethod(e.target.value)} className="w-4 h-4 text-accent accent-accent" />
                      <div className="flex-1">
                        <span className="font-medium block">Cash on Delivery</span>
                        <span className="text-xs text-muted-foreground">Pay when you receive your order</span>
                      </div>
                    </label>

                  </div>

                  <button type="submit" className="w-full bg-primary text-primary-foreground py-4 mt-8 font-medium uppercase tracking-widest text-sm hover:bg-primary/90 transition-colors">
                    Place Order — {formatPrice(total)}
                  </button>
                </form>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div key="step3" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center justify-center text-center py-12">
                <div className="w-20 h-20 bg-success/10 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle2 className="w-10 h-10 text-success" />
                </div>
                <h1 className="font-serif text-4xl font-semibold mb-4">Order Confirmed</h1>
                <p className="text-muted-foreground max-w-md mb-2">Thank you for your purchase! Your order <span className="font-medium text-foreground">#{orderId}</span> has been placed successfully.</p>
                <p className="text-muted-foreground max-w-md mb-8">We will send an order confirmation email with tracking details shortly.</p>
                <Link href="/shop" className="bg-primary text-primary-foreground px-8 py-4 font-medium uppercase tracking-widest text-sm hover:bg-primary/90 transition-colors">
                  Continue Shopping
                </Link>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right Column: Order Summary */}
        {step < 3 && (
          <div className="w-full lg:w-2/5">
            <div className="bg-secondary/30 p-8 sticky top-24">
              <h2 className="font-serif text-2xl font-semibold mb-6">In Your Bag</h2>
              
              <div className="space-y-4 mb-6 max-h-[40vh] overflow-y-auto hide-scrollbar border-b border-border pb-6">
                {cart.map(item => (
                  <div key={item.id} className="flex gap-4">
                    <div className="relative w-16 h-20 bg-muted shrink-0">
                      <Image src={item.image} alt={item.name} fill className="object-cover" referrerPolicy="no-referrer" />
                      <span className="absolute -top-2 -right-2 w-5 h-5 bg-foreground text-background rounded-full text-[10px] font-bold flex items-center justify-center">{item.quantity}</span>
                    </div>
                    <div className="flex-1 flex flex-col justify-center">
                      <span className="text-sm font-medium line-clamp-1">{item.name}</span>
                      <span className="text-xs text-muted-foreground">{item.size && `Size: ${item.size}`}</span>
                    </div>
                    <span className="text-sm font-medium">{formatPrice(item.price * item.quantity)}</span>
                  </div>
                ))}
              </div>

              <div className="space-y-3 text-sm mb-6">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="font-medium">{formatPrice(cartTotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span className="font-medium text-success">Free</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Estimated GST (18%)</span>
                  <span className="font-medium">{formatPrice(cartTotal * 0.18)}</span>
                </div>
              </div>

              <div className="border-t border-border pt-4 mb-8 flex justify-between items-center">
                <span className="font-semibold uppercase tracking-wide">Total</span>
                <span className="font-serif text-2xl font-semibold">{formatPrice(total)}</span>
              </div>

              <div className="flex items-start gap-3 text-xs text-muted-foreground p-4 bg-background border border-border">
                <ShieldCheck className="w-5 h-5 text-success shrink-0" />
                <p><strong>Secure Checkout</strong> — Your payment information is processed securely. We never store your credit card details.</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
